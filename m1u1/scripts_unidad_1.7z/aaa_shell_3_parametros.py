import sys

# python aaa_shell_2_parametros.py v1 v2 v3
print(sys.argv[0])
print(sys.argv[1])
print(sys.argv[2])
print(sys.argv[3])
print(sys.argv)
print(type(sys.argv))
print(len(sys.argv))

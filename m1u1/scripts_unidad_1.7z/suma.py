variable = "2" + "5"
print(variable)

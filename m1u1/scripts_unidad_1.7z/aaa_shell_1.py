valor_recuperado = input("Ingrese un valor por consola: ")

valor_recuperado = int(valor_recuperado)
print(valor_recuperado)
print(type(valor_recuperado))


valor_recuperado = str(valor_recuperado)
print(valor_recuperado)
print(type(valor_recuperado))

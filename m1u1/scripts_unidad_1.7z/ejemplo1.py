mi_variable = "Anna"
print(type(mi_variable))
print(mi_variable)

"""
Cambie el valor de la 
variable de string a entero
"""
mi_variable = 7
print(type(mi_variable))
print(mi_variable)


print("hola1")
print("hola2")

"""
LINTERS
pip install bandit
pip install flake8
pip install mypy
pip install prospector
pip install pycodestyle
pip install pydocstyle
pip install pylama
pip install pylint

FIXERS
pip install pytest
pip install pre-commit
pip install black


"""

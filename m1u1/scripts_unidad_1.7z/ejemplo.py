variable_1 = "Pera"
variable_2 = variable_1

print(variable_1)
print(variable_2)

variable_1 = "Auto"


print(variable_1)
print(variable_2)

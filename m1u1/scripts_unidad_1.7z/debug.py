variable1 = 2
variable2 = 3
print("Hola 1")
print("Hola 2")
variable3 = variable1 * variable2
print(variable3)
print("---" * 21)

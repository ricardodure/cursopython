archivo = open("archivo1.txt", "w")
archivo.write("Texto agregado desde script\n")
archivo.close()
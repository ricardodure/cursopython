lista = ["[1,2,3]", "['Pera', 'Limón']\n", "{'id':1, 'nombre':'Anna'}"]
print(lista)
print(lista[0])
print(type(lista[0]))

objeto_0=eval(lista[0])
print(objeto_0)
print(type(objeto_0))

objeto_1=eval(lista[1])
print(objeto_1)
print(type(objeto_1))

objeto_2=eval(lista[2])
print(objeto_2)
print(type(objeto_2))
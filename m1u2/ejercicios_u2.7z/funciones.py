def suma(param1, param2):

    print(param1 + param2)
    param3 = param1 + param2
    return param3


def multiplicar(param1, param2):

    print(param1 * param2)


resultado = suma(2, 3)
multiplicar(resultado, 3)

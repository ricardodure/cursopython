numero1 = 2
numero2 = 4
numero3 = 5

"""
+
-
*
/
//
**
%
"""

print("Así sumo: ", numero1 + numero2)
print("Así resto: ", numero1 - numero2)
print("Así multiplico: ", numero1 * numero2)
print("Así divido: ", numero3 + numero1)
print("Así divido y me quedo con la parte entera: ", numero3 // numero1)
print("Así calculo el resto: ", numero1 % numero2)
print("Así potencia: ", numero2 ** numero1)

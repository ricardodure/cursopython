import os

BASE_DIR = os.path.dirname((os.path.abspath(__file__)))
ruta = os.path.join(BASE_DIR, "img", "mascotas.jpg")
print(BASE_DIR)
print(ruta)

# D:\000_MEDRANO_2021\004-PYTHON_DIPLOMATURA\Modulo-1-y-2\Unidad 2\ejercicios_u2\img

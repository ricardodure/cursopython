ingreso = 0


def nuevo_ingreso():
    global ingreso
    ingreso += 1
    print(ingreso)


nuevo_ingreso()
nuevo_ingreso()
nuevo_ingreso()
nuevo_ingreso()

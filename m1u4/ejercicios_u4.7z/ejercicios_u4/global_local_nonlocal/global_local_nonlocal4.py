a = 5


def funcion():
    print(a)
    a = 10


funcion()

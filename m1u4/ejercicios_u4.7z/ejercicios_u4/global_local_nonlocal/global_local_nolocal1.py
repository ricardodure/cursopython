variable1 = 5


def sumar_cinco(b):
    c = variable1 + b
    return c


print(sumar_cinco(5))

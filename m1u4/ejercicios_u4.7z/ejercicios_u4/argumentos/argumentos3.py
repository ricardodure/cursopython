def por_defecto(a, b=2, c=3):
    print(a, b, c)


por_defecto(1)

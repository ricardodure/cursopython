def por_posicion(x, y, z):
    print(x, y, z)


por_posicion(1, 2, 3)


def por_nombre(x, y, z):
    print(x, y, z)


por_nombre(y=2, z=3, x=1)


def por_ambos(x, y, z):
    print(x, y, z)


por_ambos(1, y=2, z=3)

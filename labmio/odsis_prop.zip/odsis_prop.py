from tkinter import *
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk, Image
import sqlite3
import os
from tkinter import messagebox
import re


####################################################### funciones propias########################################################
################################################################################################################################


def conexion():
    base_dir = os.path.dirname((os.path.abspath(__file__)))
    ruta = os.path.join(base_dir)
    con = sqlite3.connect(ruta+'\propiedades.db')

    return con


def crear_tabla(con):

    cursor = con.cursor()
    sql = """CREATE TABLE IF NOT EXISTS 'propiedades' (
	"id"	INTEGER UNIQUE,
	"barrio"	TEXT,
	"tipo"	TEXT,
	"situacion"	TEXT,
	"localidad"	TEXT,
	"direccion"	TEXT,
	"valor"	INTEGER,
	"moneda"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT))"""

    cursor.execute(sql)
    con.commit()


def string_ok(cadena):

    patron = "^[A-Za-záéíóú]"  # regex para el campo cadena
    if (re.match(patron, cadena)):
        return True
    else:
        return False


def tree_borra_total(tree):
    tree.delete(*tree.get_children())
    return (tree)


def baja(tree):

    valor = tree.selection()
    item = tree.item(valor)
    id = item['text']

    if id == "":
        men = messagebox.showinfo(
            "¡Atencion!", "Debe seleccionar un ítem para dar de baja")
        return

    con = conexion()
    cursor = con.cursor()

    respuesta = messagebox.askyesno(
        "Baja de Propiedad", "¿Seguro de dar de baja propiedad seleccionada?")

    if respuesta:
        data = (id,)
        sql = "DELETE FROM propiedades WHERE id = ?;"
        cursor.execute(sql, data)
        con.commit()
        tree_carga(tree, "SELECT * FROM propiedades order by ID")

        return (tree)


def alta(barrio, tipo, situacion, localidad, direccion, valor, moneda, tree):

    try:

        if (string_ok(barrio)) == False or (string_ok(tipo)) == False or (string_ok(situacion)) == False or (
                string_ok(localidad)) == False or (string_ok(direccion)) == False or (string_ok(moneda)) == False:
            # título, mensaje
            men = messagebox.showinfo(
                "¡Atencion!", "Revise sus datos de entrada")
            return

        respuesta = messagebox.askyesno(
            "Alta de Propiedad", "¿Seguro de dar de alta estos datos?")

        if respuesta:
            con = conexion()
            cursor = con.cursor()
            data = (barrio, tipo, situacion, localidad,
                    direccion, valor, moneda)

            sql = "INSERT INTO propiedades(barrio,tipo,situacion,localidad,direccion,valor,moneda) VALUES(?, ?, ?,?,?,?,?)"
            cursor.execute(sql, data)
            con.commit()
            tree_carga(tree, "SELECT * FROM propiedades ORDER BY id desc")

    except:

        men = messagebox.showinfo("¡Atencion!", "Revise sus datos de entrada")
        return


def edicion(barrio, tipo, situacion, localidad, direccion, importe, moneda, tree):
    valor = tree.selection()
    item = tree.item(valor)
    id = item['text']

    if id == "":
        men = messagebox.showinfo(
            "¡Atencion!", "Debe seleccionar un ítem para actualizar")
        return

    respuesta1 = messagebox.askyesno(
        "Edicion de Propiedad", "¿Seguro de dar de modificar datos datos?")

    if respuesta1:

        sql = "SELECT * FROM propiedades WHERE id=?"
    con = conexion()
    cursor = con.cursor()
    datos = cursor.execute(sql, (id,))

    resultado = datos.fetchall()
    for fila in resultado:
        ############################ determina valores actuales de las variables###
        actual_barrio = fila[1]
        actual_tipo = fila[2]
        actual_situacion = fila[3]
        actual_localidad = fila[4]
        actual_direccion = fila[5]
        actual_importe = fila[6]
        actual_moneda = fila[7]

        # verifica si hay cambios entre los elegidos y los actuales
        # en caso de ser distinto y valor  en blanco los toma
        # para la actualización
        if barrio != "" and barrio != actual_barrio:
            nuevo_barrio = barrio
        else:
            nuevo_barrio = actual_barrio

        if tipo != "" and tipo != actual_tipo:
            nuevo_tipo = tipo
        else:
            nuevo_tipo = actual_tipo

        if situacion != "" and situacion != actual_situacion:
            nuevo_situacion = situacion
        else:
            nuevo_situacion = actual_situacion

        if localidad != "" and localidad != actual_localidad:
            nuevo_localidad = localidad
        else:
            nuevo_localidad = actual_localidad

        if direccion != "" and direccion != actual_direccion:
            nuevo_direccion = direccion
        else:
            nuevo_direccion = actual_direccion

        if importe != 0 and importe != actual_importe:
            nuevo_importe = importe
        else:
            nuevo_importe = actual_importe

        if moneda != "" and moneda != actual_moneda:
            nuevo_moneda = moneda
        else:
            nuevo_moneda = actual_moneda

        con = conexion()
        cursor = con.cursor()
        data = (nuevo_barrio, nuevo_tipo, nuevo_situacion, nuevo_localidad,
                nuevo_direccion, nuevo_importe, nuevo_moneda, id)
        sql1 = "UPDATE propiedades SET barrio=?,tipo=?,situacion=?,localidad=?,direccion=?,valor=?,moneda=? WHERE id=?"
        cursor.execute(sql1, data)
        con.commit()
        tree_carga(tree, "SELECT * FROM propiedades ORDER BY id desc")


def tree_inicializa():

    ################ barra vertical######################
    scroll_v = Scrollbar(ventana)
    scroll_v.pack(side=RIGHT, fill="y")
    ######################## barra horizontal##############

    scroll_h = Scrollbar(ventana, orient=HORIZONTAL)
    scroll_h.pack(side=BOTTOM, fill="x")

    # define columns
    columns = ("col_id", "col_barrio", "col_tipo",
               "col_situacion", "col_localidad", "col_direccion", "col_importe", "col_moneda")

    tree = ttk.Treeview(ventana, height=18, columns=columns,  show='headings',
                        yscrollcommand=scroll_v.set,
                        xscrollcommand=scroll_h.set)

    # define headings
    tree.column('col_id', width=5, anchor='w')
    tree.column('col_barrio', width=200, anchor='w')
    tree.column('col_tipo', width=200)
    tree.column('col_situacion', width=200)
    tree.column('col_localidad', width=200)
    tree.column('col_direccion', width=200)
    tree.column('col_importe', width=200)
    tree.column('col_moneda', width=200)

    tree.heading('col_id', text='ID', anchor='e')
    tree.heading('col_barrio', text='BARRIO', anchor='w')
    tree.heading('col_tipo', text='TIPO', anchor='w')
    tree.heading('col_situacion', text='SITUACION', anchor='w')
    tree.heading('col_localidad', text='LOCALIDAD', anchor='w')
    tree.heading('col_direccion', text='DIRECCION', anchor='w')
    tree.heading('col_importe', text='IMPORTE', anchor='w')
    tree.heading('col_moneda', text='MONEDA', anchor='w')

    tree.pack(fill=BOTH,  padx=30, pady=224)

    scroll_h.config(command=tree.xview)
    scroll_v.config(command=tree.yview)

    return (tree)


def arma_consulta(barrio, tipo, situacion, localidad, direccion, valor, moneda, tree):

    sql0 = "WHERE id>0"

    if barrio != "":
        sql1 = f" AND barrio LIKE '%{barrio}%'"
    else:
        sql1 = ""

    if tipo != "":
        sql2 = f" AND tipo LIKE '%{tipo}%'"
    else:
        sql2 = ""

    if situacion != "":
        sql3 = f" AND situacion LIKE '%{situacion}%'"
    else:
        sql3 = ""

    if localidad != "":
        sql4 = f" AND localidad LIKE '%{localidad}%'"
    else:
        sql4 = ""

    if direccion != "":
        sql5 = f" AND direccion LIKE '%{direccion}%'"
    else:
        sql5 = ""

    if valor > 0:
        sql6 = f" AND valor<={valor}"
    else:
        sql6 = ""

    if moneda != "":
        sql7 = f" AND moneda LIKE '%{moneda}%'"
    else:
        sql7 = ""

    sql_final = "SELECT * FROM propiedades " + \
        sql0 + sql1+sql2+sql3+sql4+sql5+sql6+sql7

    tree_carga(tree, sql_final)

    return


def tree_carga(tree, sql):
    tree_borra_total(tree)

    opcion_barrio.set("")
    opcion_tipo.set("")
    opcion_situacion.set("")
    opcion_localidad.set("")
    opcion_direccion.set("")
    opcion_moneda.set("")
    opcion_importe.set(0)

    con = conexion()
    cursor = con.cursor()
    datos = cursor.execute(sql)

    resultado = datos.fetchall()
    for fila in resultado:

        tree.insert("", 0, text=fila[0], values=(
            fila[0], fila[1], fila[2], fila[3], fila[4], fila[5], fila[6], fila[7]))

    return (tree)


######################### inicializas listas de opciones combos##########
barrios = ["Acupo 1", "Acupo 2", "Acupo 3", "CECO 1", "CECO 2", "Microcentro", "Facundo Quiroga",
           "Independencia", "Barrio Jardín", "Loma Negra", "Los Robles", "Lujan", "Mariano Moreno"]
barrios.sort()

situaciones = ["En alquiler", "Alquilada", "En venta", "Vendida",
               "En arrendamiento", "Arrendada", "Venta o alquiler", "Venta o arrendamiento"]
situaciones.sort()

tipos = ["Baulera", "Casa 1 dormitorio", "Casa 2 dormitorios",
         "Casa 3 y 4 dormitorios", "Casa con local", "Casaquinta", "Cochera",
         "Departamento 1 dormitorio", "Departamento 2 dormitorios", "Departamento 3 dormitorios",
         "Local comercial", "Local industrial", "Quinta", "Terreno"]

localidades = ["Olavarría", "Loma Negra", "Sierra Chica",
               "Hinojo", "Sierras Bayas", "Colonia San Miguel", "Bella Vista",
               "Colonia Hinojo", "Blanca Chica", "Blanca Grande"]
localidades.sort()
monedas = ["dolares", "pesos", "euros"]


# inicio ventana
ventana = Tk()
################## estilos de botones#####################
estilo1 = ttk.Style()
estilo1.configure("boton.TButton", foreground="#2200FF",
                  font=("Times", 12))


########################## titulo ventanas############################
ventana.title("Sistema Control de Propiedades OdSis-Propiedades Version 1.0")


######################## Tamaño y posicionamiento###################
ancho_ventana = 1100
alto_ventana = 600

x_ventana = ventana.winfo_screenwidth() // 2 - ancho_ventana // 2
y_ventana = ventana.winfo_screenheight() // 2 - alto_ventana // 2

posicion = str(ancho_ventana) + "x" + str(alto_ventana) + \
    "+" + str(x_ventana) + "+" + str(y_ventana)
ventana.geometry(posicion)
ventana.resizable(0, 0)

##################### fondo pantalla#############
BASE_DIR = os.path.dirname((os.path.abspath(__file__)))
ruta = os.path.join(BASE_DIR, "img", "fondo.jpg")
image_provi = Image.open(ruta)
imagen_fondo = ImageTk.PhotoImage(image_provi)

background_label = tk.Label(ventana, image=imagen_fondo)
background_label.place(x=0, y=0)
###################### icono de ventana#######################
ruta = os.path.join(BASE_DIR, "img", "icono.jpg")
image_provi2 = Image.open(ruta)
imagen_icono = ImageTk.PhotoImage(image_provi2)
ventana.iconphoto(True, imagen_icono)
####################### frame 1#############################
frame1 = LabelFrame(ventana, text="Mantenimiento de Datos de la Propiedad", width=470,
                    height=210, font=('Calibri', 12), fg='red')
frame1.place(x=65, y=10)

####################### frame 2#############################
frame2 = LabelFrame(ventana, text="Filtros de Búsqueda de Propiedades", width=470,
                    height=210, font=('Calibri', 12), fg='red')
frame2.place(x=561, y=10)

############################     BOTONES       #######################################

################## Boton de Alta##################
b_alta = ttk.Button(frame1, text="Alta Propiedad",
                    width=15, command=lambda: alta(opcion_barrio.get(), opcion_tipo.get(), opcion_situacion.get(), opcion_localidad.get(), opcion_direccion.get(), opcion_importe.get(), opcion_moneda.get(), tree), style="boton.TButton")

b_alta.place(x=50, y=150)
################## Boton de Baja##################
b_baja = ttk.Button(frame1, text="Baja Propiedad",
                    width=15, command=lambda: baja(tree), style="boton.TButton")
b_baja.place(x=180, y=150)


################## Boton de Edicion##################
b_consulta = ttk.Button(frame1, text="Edita Propiedad",
                        width=15, command=lambda: edicion(opcion_barrio.get(), opcion_tipo.get(), opcion_situacion.get(), opcion_localidad.get(), opcion_direccion.get(), opcion_importe.get(), opcion_moneda.get(), tree), style="boton.TButton")
b_consulta.place(x=310, y=150)


################## Boton de Salida del sistema##################
b_salida = ttk.Button(ventana, text="Fin del Sistema",
                      width=30, command=lambda: ventana.quit(), style="boton.TButton")
b_salida.place(x=800, y=550)

####################################### LABELS#####################################
l_barrio = ttk.Label(frame1, text="    Barrio:",
                     style="TLabel", foreground="blue", font=("times", 11, "bold"))
l_barrio.place(x=70, y=2)

l_tipo = ttk.Label(frame1, text="       Tipo:",
                   style="TLabel", foreground="Blue", font=("times", 11, "bold"))
l_tipo.place(x=70, y=22)


l_situacion = ttk.Label(frame1, text="Situación:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))

l_situacion.place(x=70, y=42)


l_localidad = ttk.Label(frame1, text="Localidad:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))

l_localidad.place(x=70, y=62)

l_direccion = ttk.Label(frame1, text="Direccion:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))
l_direccion.place(x=70, y=82)


l_valor = ttk.Label(frame1, text="       Valor:",
                    style="TLabel", foreground="blue", font=("times", 11, "bold"))

l_valor.place(x=70, y=102)

l_moneda = ttk.Label(frame1, text="   Moneda:",
                     style="TLabel", foreground="blue", font=("times", 11, "bold"))
l_moneda.place(x=70, y=122)


# Defino variables para tomar valores de campos de entrada
opcion_barrio = StringVar()
w_ancho = 20
######################### combobox barrio#########################
opcion_barrio = tk.StringVar()
combo_barrio = ttk.Combobox(frame1,
                            width=30,
                            textvariable=opcion_barrio,
                            values=barrios,
                            foreground="red"
                            )
combo_barrio.place(x=150, y=2)
combo_barrio.option_add('*TCombobox*Listbox.foreground' %
                        frame1, 'red')  # pone color azul lista desplegable

opcion_tipo = StringVar()
######################### combobox tipo#########################

combo_tipos = ttk.Combobox(frame1,
                           width=30,
                           textvariable=opcion_tipo,
                           values=tipos,
                           foreground="red"
                           )
combo_tipos.place(x=150, y=22)
######################### combobox situacion#########################
opcion_situacion = StringVar()
combo_situacion = ttk.Combobox(frame1,
                               width=30,
                               textvariable=opcion_situacion,
                               values=situaciones,
                               foreground="red"
                               )
combo_situacion.place(x=150, y=42)

######################### combobox localidades#########################
opcion_localidad = StringVar()
combo_localidades = ttk.Combobox(frame1,
                                 width=30,
                                 textvariable=opcion_localidad,
                                 values=localidades,
                                 foreground="red"
                                 )
combo_localidades.place(x=150, y=62)

# entrys de direccion y valor
opcion_direccion = StringVar()

e_direccion = Entry(frame1, textvariable=opcion_direccion,
                    font=('times', 10), width=33, foreground="Red", highlightthickness=1)
e_direccion.place(x=150, y=82)

opcion_importe = IntVar()

e_importe = Entry(frame1, textvariable=opcion_importe,
                  font=('times', 10), width=33, foreground="Red", highlightthickness=1)
e_importe.place(x=150, y=102)

######################### combobox localidades#########################
opcion_moneda = StringVar()
combo_monedas = ttk.Combobox(frame1,
                             width=30,
                             textvariable=opcion_moneda,
                             values=monedas,
                             foreground="red"
                             )
combo_monedas.place(x=150, y=122)


############################################################## WIDGETS DE LAS CONSULTAS####################################
####################################### LABELS#####################################
l_barrio = ttk.Label(frame2, text="    Barrio:",
                     style="TLabel", foreground="blue", font=("times", 11, "bold"))
l_barrio.place(x=70, y=2)

l_tipo = ttk.Label(frame2, text="       Tipo:",
                   style="TLabel", foreground="Blue", font=("times", 11, "bold"))
l_tipo.place(x=70, y=22)


l_situacion = ttk.Label(frame2, text="Situación:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))

l_situacion.place(x=70, y=42)


l_localidad = ttk.Label(frame2, text="Localidad:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))

l_localidad.place(x=70, y=62)

l_direccion = ttk.Label(frame2, text="Direccion:",
                        style="TLabel", foreground="Blue", font=("times", 11, "bold"))
l_direccion.place(x=70, y=82)


l_valor = ttk.Label(frame2, text="Valor máximo:",
                    style="TLabel", foreground="blue", font=("times", 11, "bold"))

l_valor.place(x=45, y=102)

l_moneda = ttk.Label(frame2, text="   Moneda:",
                     style="TLabel", foreground="blue", font=("times", 11, "bold"))
l_moneda.place(x=70, y=122)
########################################################################################
######################### combobox barrio#########################
copcion_barrio = StringVar()
ccombo_barrio = ttk.Combobox(frame2,
                             width=30,
                             textvariable=copcion_barrio,
                             values=barrios,
                             foreground="red"
                             )
ccombo_barrio.place(x=150, y=2)
ccombo_barrio.option_add('*TCombobox*Listbox.foreground' %
                         frame2, 'red')  # pone color azul lista desplegable


######################### combobox tipo#########################
copcion_tipo = StringVar()
ccombo_tipos = ttk.Combobox(frame2,
                            width=30,
                            textvariable=copcion_tipo,
                            values=tipos,
                            foreground="red"
                            )
ccombo_tipos.place(x=150, y=22)
######################### combobox situacion#########################
copcion_situacion = StringVar()
ccombo_situacion = ttk.Combobox(frame2,
                                width=30,
                                textvariable=copcion_situacion,
                                values=situaciones,
                                foreground="red"
                                )
ccombo_situacion.place(x=150, y=42)

######################### combobox localidades#########################
copcion_localidad = StringVar()
ccombo_localidades = ttk.Combobox(frame2,
                                  width=30,
                                  textvariable=copcion_localidad,
                                  values=localidades,
                                  foreground="red"
                                  )
ccombo_localidades.place(x=150, y=62)

# entrys de direccion y valor
copcion_direccion = StringVar()

ce_direccion = Entry(frame2, textvariable=copcion_direccion,
                     font=('times', 10), width=33, foreground="Red", highlightthickness=1)
ce_direccion.place(x=150, y=82)

copcion_importe = IntVar()

ce_importe = Entry(frame2, textvariable=copcion_importe,
                   font=('times', 10), width=33, foreground="Red", highlightthickness=1)
ce_importe.place(x=150, y=102)

######################### combobox localidades#########################
copcion_moneda = StringVar()
ccombo_monedas = ttk.Combobox(frame2,
                              width=30,
                              textvariable=copcion_moneda,
                              values=monedas,
                              foreground="red"
                              )
ccombo_monedas.place(x=150, y=122)

################## Boton Lista Propiedades##################
b_lista = ttk.Button(frame2, text="Lista Total de Propiedades",
                     width=25, command=lambda: tree_carga(tree, "SELECT * FROM propiedades ORDER BY id desc"), style="boton.TButton")
b_lista.place(x=28, y=150)
################## Boton de Baja##################
b_filtra = ttk.Button(frame2, text="Lista Aplicando Filtros",
                      width=25, command=lambda: arma_consulta(copcion_barrio.get(), copcion_tipo.get(), copcion_situacion.get(), copcion_localidad.get(), copcion_direccion.get(), copcion_importe.get(), copcion_moneda.get(), tree), style="boton.TButton")
b_filtra.place(x=229, y=150)


############################################## main##################################
tree = tree_inicializa()
# try:

con = conexion()
crear_tabla(con)
tree_carga(tree, "SELECT * FROM propiedades ORDER BY id desc")
# except:
# print("Hay un error")

######################### cierre ventana##################

ventana.mainloop()

<!Doctype html> 
<html>  
	<head>   
		<title>Beautiful soup recorrer html</title> 
	</head>  
	<body>   
		<p class ="titulo">
			<b>Título de la historia</b>
		</p>  
		<p class = "contenido">Contenido de la historia  
			<a href="ruta 1" class = "estiloAncla" id="link1"> 
				historia 1
			</a>  
			<a href="ruta 1" class = "estiloAncla" id="link2"> 
				historia 2
			</a>  
			<a href="ruta 1" class = "estiloAncla" id="link3"> 
				historia 3
			</a>  
			<a href="ruta 1" class = "estiloAncla" id="link4"> 
				historia 4
			</a>  
		</p>   
		<p class ="historia">……………..</p> 
	</body> 
</html>
<?php 

$variable1 = $_GET['variable1']; 
$variable2 = $_GET['variable2']; 
echo "El valor de la variable 1 es: " . $variable1 . " y el de la variable 2 es: " . $variable2;
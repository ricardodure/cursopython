<?php
echo 'Titulo: '.$_GET['idtitulo'];
echo '<br>';
echo 'Contenido: '.$_GET['idcontenido'];
?>
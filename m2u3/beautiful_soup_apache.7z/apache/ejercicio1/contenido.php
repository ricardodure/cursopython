<?php
	echo '<b>Este es el contenido de un determinado artículo</b>';
?>
variable=input("Ingrese la contraseña: ")
password="abc123"

while variable!=password:
    variable=input("La contraseña no es correcta, por favor ingrese la contraseña: ")
print("La contraseña es correcta")
set1 = {1, 2, 3, 3, 5, 1, 7}
print(set1)
print(type(set1))

mi_lista1 = [1, 2, 3, 3, 5, 1, 7]
set2 = set(mi_lista1)
print(mi_lista1)
print(set2)
mi_lista1 = list(set2)
print(mi_lista1)

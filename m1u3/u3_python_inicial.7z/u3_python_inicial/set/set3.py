set1 = {1, 2, 3, 3, 5, 1, 7}
set2 = {1, 2, 3, 3, 5, 1, 7, 10, 21, 33}
set3 = {1, 2, 3, 3, 5, 1, 7, 21, 33}

# Para intersección utilizo &
print(set2 & set3)

# Para unión utilizo |
print(set2 | set3)

# Para diferencia utilizo -
print(set2 - set3)

# Para
print(set2 > set3)

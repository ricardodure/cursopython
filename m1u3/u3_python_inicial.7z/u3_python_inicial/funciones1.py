def suma(a, b):
    c = a + b
    return a, b, c


a, b, c = suma(2, 3)
print(a, b, c)

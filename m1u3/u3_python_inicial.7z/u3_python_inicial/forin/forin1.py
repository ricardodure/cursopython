fruta = "manzana"

for x in fruta:
    print(x)


frutas = ["manzana", "pera", "limón"]

for x in frutas:
    print(x)


for x in range(7):
    if x == 3:
        continue
    print(x)

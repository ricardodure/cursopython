nombre = "Pepe"
edad = 40

print(f"La edad de {nombre} es de {edad} años")

valor = 3.141659
print(f"El valor de pi es {valor:.3f}")

nombre = "Pepe"
edad = 40

print("La edad de {0} es de {1} años".format(nombre, edad))
